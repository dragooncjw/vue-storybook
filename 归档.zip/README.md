# Storybook Demo

This is a demo app to test VueJs integration with Storybook. Run `yarn install` to sync Storybook module with the source code and run `yarn storybook` to start the Storybook.
